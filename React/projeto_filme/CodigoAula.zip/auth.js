

export const autenticado = () => {
    return false;
}
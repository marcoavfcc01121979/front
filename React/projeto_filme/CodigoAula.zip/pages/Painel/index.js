import React from 'react';

const Painel = () => {
    return(
        <div>
            <h1>Bem vindo você esta logado!</h1>
        </div>
    );
}

export default Painel;
import React, {Component } from 'react';

class Erro extends Component{
    render(){
        return(
            <div>
                <h1>Pagina não encontrada!</h1>
            </div>
        );
    }
}

export default Erro;